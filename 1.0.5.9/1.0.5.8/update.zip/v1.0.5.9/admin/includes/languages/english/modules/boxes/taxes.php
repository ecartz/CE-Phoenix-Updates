<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2020 osCommerce

  Released under the GNU General Public License
*/

  define('BOX_HEADING_LOCATION_AND_TAXES', '<i title="Locations & Taxes" data-toggle="tooltip" data-placement="right" class="fas fa-comments-dollar fa-fw mr-1"></i><span class="d-inline d-md-none">Locations & Taxes</span>');
  