<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2020 osCommerce

  Released under the GNU General Public License
*/

  define('BOX_HEADING_LOCALIZATION', '<i title="Localization" data-toggle="tooltip" data-placement="right" class="fas fa-language fa-fw mr-1"></i><span class="d-inline d-md-none">Localization</span>');
  