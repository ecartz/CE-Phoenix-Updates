<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2020 osCommerce

  Released under the GNU General Public License
*/

define('HEADING_TITLE', 'Newsletter Manager');

define('TABLE_HEADING_NEWSLETTERS', 'Name');
define('TABLE_HEADING_DATE_ADDED', 'Date Added');
define('TABLE_HEADING_SIZE', 'Size');
define('TABLE_HEADING_MODULE', 'Type');
define('TABLE_HEADING_SENT', 'Sent');
define('TABLE_HEADING_STATUS', 'Status');
define('TABLE_HEADING_ACTION', 'Action');

define('TEXT_NEWSLETTER_MODULE', 'Module:');
define('TEXT_NEWSLETTER_TITLE', 'Newsletter Title:');
define('TEXT_NEWSLETTER_CONTENT', 'Content:');

define('TEXT_NEWSLETTER_DATE_ADDED', 'Date Added: %s');
define('TEXT_NEWSLETTER_DATE_SENT', 'Date Sent: %s');

define('TEXT_INFO_DELETE_INTRO', 'Are you sure you want to delete this newsletter?');

define('TEXT_PLEASE_WAIT', 'Please wait .. sending emails ..<br /><br />Please do not interrupt this process!');
define('TEXT_FINISHED_SENDING_EMAILS', 'Finished sending e-mails!');

define('ERROR_NEWSLETTER_TITLE', '<strong>Error:</strong> Newsletter title required');
define('ERROR_NEWSLETTER_MODULE', '<strong>Error:</strong> Newsletter module required');
define('ERROR_REMOVE_UNLOCKED_NEWSLETTER', '<strong>Error:</strong> Please lock the newsletter before deleting it.');
define('ERROR_EDIT_UNLOCKED_NEWSLETTER', '<strong>Error:</strong> Please lock the newsletter before editing it.');
define('ERROR_SEND_UNLOCKED_NEWSLETTER', '<strong>Error:</strong> Please lock the newsletter before sending it.');

define('ERROR_NEWSLETTER_MODULE_NOT_EXISTS', '<strong>Error:</strong> Module does not exist');

define('TEXT_TITLE', 'Title:');
define('TEXT_CONTENT', 'Content:');
