<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2020 osCommerce

  Released under the GNU General Public License
*/

  define('BOX_HEADING_TOOLS', '<i title="Tools" data-toggle="tooltip" data-placement="right" class="fas fa-tools fa-fw mr-1"></i><span class="d-inline d-md-none">Tools</span>');
  