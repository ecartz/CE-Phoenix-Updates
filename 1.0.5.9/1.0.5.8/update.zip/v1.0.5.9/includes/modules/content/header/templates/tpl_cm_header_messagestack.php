<div class="col-sm-<?php echo $content_width; ?> cm-header-messagestack">
  <?php echo $messageStack->output('header'); ?>
</div>

<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2020 osCommerce

  Released under the GNU General Public License
*/
?>
