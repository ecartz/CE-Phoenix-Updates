<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2020 osCommerce

  Released under the GNU General Public License
*/

  define('MODULE_CONTENT_FOOTER_EXTRA_ICONS_TITLE', 'Payment Icons');
  define('MODULE_CONTENT_FOOTER_EXTRA_ICONS_DESCRIPTION', 'Adds Brand Icons to the Extra Footer Area of your site.<div class="alert alert-info">Available Brand Icons are shown here: https://fontawesome.com/icons?d=gallery&s=brands&c=payments-shopping</div>');
  
  define('MODULE_CONTENT_FOOTER_EXTRA_ICONS_TEXT', '');

