<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2020 osCommerce

  Released under the GNU General Public License
*/

  const PI_BUY_TITLE       = 'Buy Button';
  const PI_BUY_DESCRIPTION = 'Shows the Buy Button on the product_info Page.<div class="alert alert-info">This is a child module for use with the &pi; system.</div>';
  
  const PI_BUY_BUTTON_TEXT = 'Add To Cart';
