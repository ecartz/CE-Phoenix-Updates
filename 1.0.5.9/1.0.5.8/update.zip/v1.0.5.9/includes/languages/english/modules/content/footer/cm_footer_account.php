<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2020 osCommerce

  Released under the GNU General Public License
*/

  define('MODULE_CONTENT_FOOTER_ACCOUNT_TITLE', 'Account Links');
  define('MODULE_CONTENT_FOOTER_ACCOUNT_DESCRIPTION', 'Adds Account Links to the Footer Area of your site');

  define('MODULE_CONTENT_FOOTER_ACCOUNT_HEADING_TITLE', 'Customer Services');

  define('MODULE_CONTENT_FOOTER_ACCOUNT_BOX_ACCOUNT', 'My Profile');
  define('MODULE_CONTENT_FOOTER_ACCOUNT_BOX_ADDRESS_BOOK', 'My Address Book');
  define('MODULE_CONTENT_FOOTER_ACCOUNT_BOX_ORDER_HISTORY', 'My Order History');
  define('MODULE_CONTENT_FOOTER_ACCOUNT_BOX_LOGOFF', 'Secure Log Off');
  define('MODULE_CONTENT_FOOTER_ACCOUNT_BOX_CREATE_ACCOUNT', 'Create a Profile');
  define('MODULE_CONTENT_FOOTER_ACCOUNT_BOX_LOGIN', 'Existing Customer? Log In');

