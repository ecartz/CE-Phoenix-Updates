<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2019 osCommerce

  Released under the GNU General Public License
*/

define('HEADING_TITLE', 'Security Checks');

define('TABLE_HEADING_TITLE', 'Title');
define('TABLE_HEADING_MODULE', 'Module');
define('TABLE_HEADING_INFO', 'Info');
