<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2020 osCommerce

  Released under the GNU General Public License
*/

define('MODULE_ADMIN_DASHBOARD_PHOENIX_ADDONS_TITLE', 'Latest CERTIFIED Add-Ons');
define('MODULE_ADMIN_DASHBOARD_PHOENIX_ADDONS_DESCRIPTION', 'Show the latest Add-Ons for Phoenix Club members');

define('MODULE_ADMIN_DASHBOARD_PHOENIX_ADDONS_OWNER', 'By');
define('MODULE_ADMIN_DASHBOARD_PHOENIX_ADDONS_RATING', 'Rating');

define('MODULE_ADMIN_DASHBOARD_PHOENIX_JOIN_CLUB', 'Join the Club');
define('MODULE_ADMIN_DASHBOARD_PHOENIX_VIEW_ALL', 'View full list of Certified Addons');
