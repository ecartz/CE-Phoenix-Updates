<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2020 osCommerce

  Released under the GNU General Public License
*/

  const PI_MODEL_TITLE         = 'Model';
  const PI_MODEL_DESCRIPTION   = 'Shows the Products Model on the Product Info Page.<div class="secInfo">This is a child module for use with the &pi; system.</div>';
  
  const PI_MODEL_DISPLAY_MODEL = 'Model:<span class="badge badge-primary badge-pill">%s</span>';
