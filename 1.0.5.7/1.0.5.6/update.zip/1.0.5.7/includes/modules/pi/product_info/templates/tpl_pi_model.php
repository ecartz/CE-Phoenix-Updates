<div class="col-sm-<?php echo $content_width; ?> pi-model mb-2">
  <ul class="list-group">
    <li class="list-group-item d-flex justify-content-between align-items-center">
      <?php echo sprintf(PI_MODEL_DISPLAY_MODEL, $products_model); ?>
    </li>    
  </ul>
</div>

<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2020 osCommerce

  Released under the GNU General Public License
*/
?>
