<div class="col-sm-<?php echo $content_width; ?> pi-img-disclaimer">
  <div class="alert alert-light mt-2">
    <?php echo PI_IMG_DISCLAIMER_TEXT; ?>
  </div>
</div>

<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2020 osCommerce

  Released under the GNU General Public License
*/
?>
