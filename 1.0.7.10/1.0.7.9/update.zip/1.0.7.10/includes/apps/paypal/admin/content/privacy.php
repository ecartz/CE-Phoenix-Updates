<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2014 osCommerce

  Released under the GNU General Public License
*/
?>

<h1 class="display-4"><?php echo $OSCOM_PayPal->getDef('privacy_title'); ?></h1>

<?php echo $OSCOM_PayPal->getDef('privacy_body'); ?>
