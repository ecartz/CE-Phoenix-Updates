<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2020 osCommerce

  Released under the GNU General Public License
*/

  define('BOX_HEADING_CATALOG', '<i data-content="Catalog" data-toggle="popover" data-placement="right" class="fas fa-cart-plus fa-fw mr-1"></i><span class="d-inline d-md-none">Catalog</span>');
