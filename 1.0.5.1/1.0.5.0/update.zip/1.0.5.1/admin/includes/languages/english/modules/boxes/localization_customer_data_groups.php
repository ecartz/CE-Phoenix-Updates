<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2020 osCommerce

  Released under the GNU General Public License
*/

const BOX_LOCALIZATION_CUSTOMER_DATA_GROUPS = 'Customer Data Groups';
