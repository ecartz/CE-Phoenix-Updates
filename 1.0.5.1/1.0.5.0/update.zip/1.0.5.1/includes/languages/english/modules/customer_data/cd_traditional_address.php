<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2020 osCommerce

  Released under the GNU General Public License
*/

const MODULE_CUSTOMER_DATA_TRADITIONAL_ADDRESS_TEXT_TITLE = 'Traditional Address';
const MODULE_CUSTOMER_DATA_TRADITIONAL_ADDRESS_TEXT_DESCRIPTION = 'The traditional osCommerce address.';
