<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2020 osCommerce

  Released under the GNU General Public License
*/

const MODULE_CUSTOMER_DATA_INFORMAL_SHORT_NAME_TEXT_TITLE = 'Informal short name';
const MODULE_CUSTOMER_DATA_INFORMAL_SHORT_NAME_TEXT_DESCRIPTION = 'Use the first name as the short name';
