<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2020 osCommerce

  Released under the GNU General Public License
*/

const MODULE_CUSTOMER_DATA_NAME_2_TEXT_TITLE = 'Two part name';
const MODULE_CUSTOMER_DATA_NAME_2_TEXT_DESCRIPTION = 'Show name (first, last) in customer data';
