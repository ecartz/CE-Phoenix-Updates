<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2020 osCommerce

  Released under the GNU General Public License
*/

const MODULE_CUSTOMER_DATA_CITY_TEXT_TITLE = 'City';
const MODULE_CUSTOMER_DATA_CITY_TEXT_DESCRIPTION = 'Show a city field in customer registration';

const ENTRY_CITY = 'City';
const ENTRY_CITY_ERROR = 'Your City must contain a minimum of %d characters.';
const ENTRY_CITY_TEXT = '';
