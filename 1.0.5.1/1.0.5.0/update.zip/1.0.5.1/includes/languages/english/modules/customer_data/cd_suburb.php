<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2020 osCommerce

  Released under the GNU General Public License
*/

const MODULE_CUSTOMER_DATA_SUBURB_TEXT_TITLE = 'Suburb';
const MODULE_CUSTOMER_DATA_SUBURB_TEXT_DESCRIPTION = 'Show a suburb field in customer registration';

const ENTRY_SUBURB = 'Suburb';
const ENTRY_SUBURB_ERROR = 'Your Suburb must contain a minimum of %d characters.';
const ENTRY_SUBURB_TEXT = '';
