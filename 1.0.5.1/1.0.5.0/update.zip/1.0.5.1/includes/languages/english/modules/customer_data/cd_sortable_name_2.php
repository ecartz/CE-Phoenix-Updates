<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2020 osCommerce

  Released under the GNU General Public License
*/

const MODULE_CUSTOMER_DATA_SORTABLE_NAME_2_TEXT_TITLE = 'Sortable name (last, first)';
const MODULE_CUSTOMER_DATA_SORTABLE_NAME_2_TEXT_DESCRIPTION = 'Show name (last, first) where sorted by last name';
