<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2020 osCommerce

  Released under the GNU General Public License
*/
?>
  <div class="form-group row">
    <label for="<?php echo $input_id; ?>" class="col-form-label col-sm-3 text-left text-sm-right"><?php echo $label_text; ?></label>
    <div class="col-sm-9"><?php echo $input; ?></div>
  </div>
