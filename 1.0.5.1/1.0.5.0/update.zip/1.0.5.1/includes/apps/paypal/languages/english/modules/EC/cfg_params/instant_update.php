cfg_ec_instant_update_title = Instant Update
cfg_ec_instant_update_desc = Enable this to have PayPal retrieve a list of shipping rates after the customer has selected their shipping address during the Express Checkout flow.<br><br><em>Instant Update requires SSL to be enabled on your store.</em>

cfg_ec_instant_update_enabled = Enabled
cfg_ec_instant_update_disabled = Disabled
