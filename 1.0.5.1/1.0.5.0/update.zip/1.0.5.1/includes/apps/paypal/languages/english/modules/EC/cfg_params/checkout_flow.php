cfg_ec_checkout_flow_title = Checkout Flow
cfg_ec_checkout_flow_desc = Use the new pop-up In-Context checkout flow and have PayPal automatically choose the best checkout flow to use, or use standard full-page Classic checkout flow.<br><br><em>In-Context does not yet support all of the features of the Classic checkout flow such as Instant Update.</em>

cfg_ec_checkout_flow_default = Classic
cfg_ec_checkout_flow_in_context = In-Context
