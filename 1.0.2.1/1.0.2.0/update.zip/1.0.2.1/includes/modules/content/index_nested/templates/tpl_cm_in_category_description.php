<div class="col-sm-<?php echo $content_width; ?> cm-in-category-description">
  <div class="card bg-light card-body mb-3 card bg-faded p-1 mb-3">
    <?php echo $category_description; ?>
  </div>
</div>
