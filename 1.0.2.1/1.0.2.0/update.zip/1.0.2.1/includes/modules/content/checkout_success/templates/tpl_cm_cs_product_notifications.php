<div class="col-sm-12 cm-cs-product-notifications">
  <div class="card mb-2">
    <div class="card-header">
      <?php echo MODULE_CONTENT_CHECKOUT_SUCCESS_PRODUCT_NOTIFICATIONS_TEXT_NOTIFY_PRODUCTS; ?>
    </div>
    <div class="card-body">
      <p class="productsNotifications">
        <?php echo $products_notifications; ?>
      </p>
    </div>
  </div>
</div>
