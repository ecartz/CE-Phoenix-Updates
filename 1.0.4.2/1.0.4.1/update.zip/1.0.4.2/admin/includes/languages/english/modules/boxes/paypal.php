<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2014 osCommerce

  Released under the GNU General Public License
*/

  define('MODULES_ADMIN_MENU_PAYPAL_HEADING', '<i class="fab fa-paypal fa-fw mr-1"></i>PayPal');

  define('MODULES_ADMIN_MENU_PAYPAL_BALANCE', 'Balance');
  define('MODULES_ADMIN_MENU_PAYPAL_CONFIGURE', 'Configure');
  define('MODULES_ADMIN_MENU_PAYPAL_LOG', 'Log');
  define('MODULES_ADMIN_MENU_PAYPAL_MANAGE_CREDENTIALS', 'Credentials');
  define('MODULES_ADMIN_MENU_PAYPAL_START', 'Start');
  