<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2019 osCommerce

  Released under the GNU General Public License
*/

  define('BOX_HEADING_CUSTOMERS', '<i class="fas fa-users fa-fw mr-1"></i>Customers');
