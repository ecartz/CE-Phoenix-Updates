<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 osCommerce

  Released under the GNU General Public License
*/

define('NAVBAR_TITLE', 'Specials');
define('HEADING_TITLE', 'Get Them While They\'re Hot!');

define('TEXT_NO_PRODUCTS', 'There are no special offers available.');

// seo
define('META_SEO_TITLE', 'Special Offers Page');
define('META_SEO_DESCRIPTION', 'Specials Description');
