<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2020 osCommerce

  Released under the GNU General Public License
*/
?>
  <div class="form-group row align-items-center">
    <div class="col-form-label col-sm-3 text-left text-sm-right"><?php echo ENTRY_NEWSLETTER; ?></div>
    <div class="col-sm-9 pl-5 custom-control custom-switch">
<?php
  echo tep_draw_selection_field('newsletter', 'checkbox', 1, (1 == $newsletter), $attribute . 'class="custom-control-input" id="inputNewsletter"');
?>
      <label for="inputNewsletter" class="custom-control-label text-muted"><small><?php echo ENTRY_NEWSLETTER_TEXT; ?>&nbsp;</small></label>
    </div>
  </div>
