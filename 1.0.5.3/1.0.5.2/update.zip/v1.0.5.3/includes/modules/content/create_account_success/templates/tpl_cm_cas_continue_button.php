<div class="col-sm-<?php echo $content_width; ?> cm-cas-continue-button">
  <?php echo tep_draw_button(MODULE_CONTENT_CAS_CONTINUE_BUTTON_TEXT, 'fas fa-angle-right', $origin_href, null, null, 'btn-success btn-block btn-lg'); ?>
</div>

<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2020 osCommerce

  Released under the GNU General Public License
*/
?>
   