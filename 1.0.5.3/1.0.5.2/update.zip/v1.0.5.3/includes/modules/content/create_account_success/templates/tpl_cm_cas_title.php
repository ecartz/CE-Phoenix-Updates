<div class="col-sm-<?php echo $content_width; ?> cm-cas-title">
  <h1 class="display-4"><?php echo MODULE_CONTENT_CAS_TITLE_PUBLIC_TITLE; ?></h1>
</div>

<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2020 osCommerce

  Released under the GNU General Public License
*/
?>
   