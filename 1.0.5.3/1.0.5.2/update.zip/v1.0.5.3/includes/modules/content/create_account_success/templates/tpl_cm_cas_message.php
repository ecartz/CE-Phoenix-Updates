<div class="col-sm-<?php echo $content_width; ?> cm-cas-message">
  <div class="alert alert-success" role="alert">
    <?php echo sprintf(MODULE_CONTENT_CAS_MESSAGE_PUBLIC_TITLE, $contact_us_href, $account_href); ?>
  </div>
</div>

<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2020 osCommerce

  Released under the GNU General Public License
*/
?>
