<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2020 osCommerce

  Released under the GNU General Public License
*/

const NAVBAR_TITLE = 'Create an Account';

const HEADING_TITLE = 'My Account Information';

const TEXT_ORIGIN_LOGIN = '<span class="text-danger"><strong>NOTE:</strong></span> If you already have an account with us, please log in at the <a class="alert-link" href="%s"><u>login page</u></a>.';
