<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2020 osCommerce

  Released under the GNU General Public License
*/

  const MODULE_CONTENT_CAS_TITLE_TITLE        = 'Page Heading';
  const MODULE_CONTENT_CAS_TITLE_DESCRIPTION  = 'Shows the Page Heading.';
  
  const MODULE_CONTENT_CAS_TITLE_PUBLIC_TITLE = 'Thanks for setting up your profile!';

  