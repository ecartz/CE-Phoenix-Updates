<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2020 osCommerce

  Released under the GNU General Public License
*/

const MODULE_CUSTOMER_DATA_COUNTRY_TEXT_TITLE = 'Country';
const MODULE_CUSTOMER_DATA_COUNTRY_TEXT_DESCRIPTION = 'Show a country field in customer registration';

const ENTRY_COUNTRY = 'Country';
const ENTRY_COUNTRY_ERROR = 'You must select a country from the countries pull down menu.';
const ENTRY_COUNTRY_TEXT = '';
