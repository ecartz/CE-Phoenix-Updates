<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2020 osCommerce

  Released under the GNU General Public License
*/

const MODULE_CUSTOMER_DATA_DATE_ACCOUNT_CREATED_TEXT_TITLE = 'Date Account Created';
const MODULE_CUSTOMER_DATA_DATE_ACCOUNT_CREATED_TEXT_DESCRIPTION = 'Show the date the account was created';
