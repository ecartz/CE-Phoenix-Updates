<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2020 osCommerce

  Released under the GNU General Public License
*/

const MODULE_CUSTOMER_DATA_GENDER_TEXT_TITLE = 'Gender';
const MODULE_CUSTOMER_DATA_GENDER_TEXT_DESCRIPTION = 'Show a gender field in customer registration';

const MALE = 'Male';
const FEMALE = 'Female';

const ENTRY_GENDER = 'Gender';
const ENTRY_GENDER_ERROR = 'Please select your Gender.';
const ENTRY_GENDER_TEXT = '';
