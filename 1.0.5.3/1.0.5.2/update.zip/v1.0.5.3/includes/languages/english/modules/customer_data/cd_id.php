<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2020 osCommerce

  Released under the GNU General Public License
*/

const MODULE_CUSTOMER_DATA_ID_TEXT_TITLE = 'Identifier';
const MODULE_CUSTOMER_DATA_ID_TEXT_DESCRIPTION = 'The customer Identifier';
