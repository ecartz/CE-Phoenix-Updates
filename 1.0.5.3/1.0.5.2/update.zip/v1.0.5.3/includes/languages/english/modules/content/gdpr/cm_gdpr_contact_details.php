<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2020 osCommerce

  Released under the GNU General Public License
*/

  const MODULE_CONTENT_GDPR_CONTACT_DETAILS_TITLE = 'GDPR Contact Details';
  const MODULE_CONTENT_GDPR_CONTACT_DETAILS_DESCRIPTION = 'Show Customers Contact Details on the GDPR page.';
  
  const MODULE_CONTENT_GDPR_CONTACT_DETAILS_PUBLIC_TITLE = 'Your Contact Details';
  
  const MODULE_CONTENT_GDPR_CONTACT_DETAILS_EMAIL = 'Email';
  const MODULE_CONTENT_GDPR_CONTACT_DETAILS_PHONE = 'Telephone';
  const MODULE_CONTENT_GDPR_CONTACT_DETAILS_FAX = 'Fax';
  const MODULE_CONTENT_GDPR_CONTACT_DETAILS_MAIN_ADDRESS = 'Main Address';
  
  const MODULE_CONTENT_GDPR_CONTACT_DETAILS_UNKNOWN = 'Unknown';
  