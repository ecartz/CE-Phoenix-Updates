<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2020 osCommerce

  Released under the GNU General Public License
*/

  const MODULE_CONTENT_GDPR_CONTACT_ADDRESSES_TITLE = 'GDPR Address Details';
  const MODULE_CONTENT_GDPR_CONTACT_ADDRESSES_DESCRIPTION = 'Show Customers *other* Addresses on the GDPR page.';
  
  const MODULE_CONTENT_GDPR_CONTACT_ADDRESSES_PUBLIC_TITLE = 'More Addresses linked to your Account';
  
  const MODULE_CONTENT_GDPR_CONTACT_ADDRESSES_NUM_ADDRESSES = 'We can find<br><span class="h1"><span class="num_addresses">%s</span></span><br> more Address(es)';
  