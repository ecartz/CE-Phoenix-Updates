<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2020 osCommerce

  Released under the GNU General Public License
*/

  define('MODULE_CONTENT_ACCOUNT_GDPR_TITLE', 'GDPR Link');
  define('MODULE_CONTENT_ACCOUNT_GDPR_DESCRIPTION', 'Adds a Link to the GDPR Page.');

  define('MODULE_CONTENT_ACCOUNT_GDPR_LINK_TITLE', 'General Data Protection Regulation (EU 2016/679)');
  define('MODULE_CONTENT_ACCOUNT_GDPR_SUB_TITLE', 'GDPR');
  