<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2020 osCommerce

  Released under the GNU General Public License
*/

  const MODULE_CONTENT_PI_GALLERY_TITLE       = 'Gallery';
  const MODULE_CONTENT_PI_GALLERY_DESCRIPTION = 'Shows the Product Image(s) on the product_info Page attached to a modal carousel.  If the Image has "htmlcontent" this will show as an overlay.';
  
  const MODULE_CONTENT_PI_GALLERY_ALBUM_NAME = 'Album for %s';
  const MODULE_CONTENT_PI_GALLERY_ALBUM_CLOSE = 'Close';
  