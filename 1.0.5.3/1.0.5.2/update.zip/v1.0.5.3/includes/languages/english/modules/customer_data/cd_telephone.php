<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2020 osCommerce

  Released under the GNU General Public License
*/

const MODULE_CUSTOMER_DATA_TELEPHONE_TEXT_TITLE = 'Telephone';
const MODULE_CUSTOMER_DATA_TELEPHONE_TEXT_DESCRIPTION = 'Show a telephone field in customer registration';

const ENTRY_TELEPHONE = 'Telephone';
const ENTRY_TELEPHONE_ERROR = 'Your Telephone must contain a minimum of %d characters.';
const ENTRY_TELEPHONE_TEXT = '';
