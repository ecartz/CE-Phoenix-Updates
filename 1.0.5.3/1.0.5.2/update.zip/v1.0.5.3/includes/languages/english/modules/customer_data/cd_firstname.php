<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2020 osCommerce

  Released under the GNU General Public License
*/

const MODULE_CUSTOMER_DATA_FIRSTNAME_TEXT_TITLE = 'First name';
const MODULE_CUSTOMER_DATA_FIRSTNAME_TEXT_DESCRIPTION = 'Show a first name field in customer registration';

const ENTRY_FIRST_NAME = 'First Name';
const ENTRY_FIRST_NAME_ERROR = 'Your First Name must contain a minimum of %d characters.';
const ENTRY_FIRST_NAME_TEXT = '';
