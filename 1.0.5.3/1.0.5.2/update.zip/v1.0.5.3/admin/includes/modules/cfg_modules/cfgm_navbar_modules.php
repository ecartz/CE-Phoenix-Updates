<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2016 osCommerce

  Released under the GNU General Public License
*/

  class cfgm_navbar_modules {

    public $code = 'navbar';
    public $directory = DIR_FS_CATALOG_MODULES . 'navbar/';
    public $language_directory = DIR_FS_CATALOG_LANGUAGES;
    public $key = 'MODULE_CONTENT_NAVBAR_INSTALLED';
    public $title = MODULE_CFG_MODULE_CONTENT_NAVBAR_TITLE;
    public $template_integration = false;

  }