<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2020 osCommerce

  Released under the GNU General Public License
*/

const WARNING_DOWNLOAD_DIRECTORY_NON_EXISTENT = 'The downloadable products directory does not exist:  [%s]. Downloadable products will not work until this directory is valid.';
