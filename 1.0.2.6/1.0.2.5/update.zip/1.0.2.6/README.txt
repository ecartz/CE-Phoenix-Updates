### Phoenix 1.0.2.6

# Demo Site:

https://template.me.uk/phoenix/index.php

# This Update;

- Fix "xs" deprecated css
- Remove "tell a friend" and associated files
- Restyle checkout procedure
- Update version to 1.0.2.6

# How to Update if on 1.0.2.5;

- Download this Zip:  you've already done this!
- Unzip it
- Upload it
- Visit admin > tools > security checks and perform any needed actions
- Enjoy using 1.0.2.6

# How to Update if on earlier version;

- Find version you are on [admin > tools > version checker]
- Go back through this discussion [ https://forums.oscommerce.com/topic/493635-phoenix-announcements/ ] and perform updates to get to 1.0.2.5
- Then follow "how to update if on 1.0.2.5" instructions

# After Update;

- Uninstall E-Mail Social Bookmark (aka sb_email)
- Uninstall Tell A Friend Action Recorder (aka ar_tell_a_friend)
- Uninstall AND Reinstall Robot Noindex Header Tag (aka ht_robot_noindex)
- Uninstall AND Reinstall Product Notifications Content Module (aka cm_cs_product_notifications)
- SQL to run (in phpmyadmin);
  delete from configuration where configuration_key = 'ALLOW_GUEST_TO_TELL_A_FRIEND';

### -OR-

# You can download and install a brand new 1.0.2.6;

- clicking the green "clone or download" button at https://github.com/gburton/CE-Phoenix
- choose "download zip"
- unzip, upload, install

# After New Installation is complete;

- Visit admin > tools > security checks and perform any needed actions
- Enjoy using 1.0.2.6

### - Join the Phoenix Club -

- https://forums.oscommerce.com/clubs/1-phoenix/
- If you are not a member of the Phoenix Club, request it; you'll get to see some of the "behind the scenes" work and help to steer future releases.