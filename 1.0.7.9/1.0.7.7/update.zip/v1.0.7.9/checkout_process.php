<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2020 osCommerce

  Released under the GNU General Public License
*/

  include 'includes/application_top.php';

  require 'includes/system/segments/checkout/pipeline.php';

  require 'includes/application_bottom.php';
