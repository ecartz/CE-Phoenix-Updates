<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2020 osCommerce

  Released under the GNU General Public License
*/

  const PI_OA_TITLE         = 'Options & Attributes';
  const PI_OA_DESCRIPTION   = 'Shows the Product Options on the product_info Page.<div class="secInfo">This is a child module for use with the &Pi; system.</div>';
  
  const PI_OA_HEADING_TITLE = 'Available Options';
  
  const PI_OA_ENFORCE_SELECTION = '--- Please Select ---';
