<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2020 osCommerce

  Released under the GNU General Public License
*/

  const PI_IMG_DISCLAIMER_TITLE       = 'Image Disclaimer';
  const PI_IMG_DISCLAIMER_DESCRIPTION = 'Shows Image Disclaimer on the Product Info Page.<div class="secInfo">This is a child module for use with the &pi; system.</div>';
  
  const PI_IMG_DISCLAIMER_TEXT = 'Product may vary slightly from image representation.';
