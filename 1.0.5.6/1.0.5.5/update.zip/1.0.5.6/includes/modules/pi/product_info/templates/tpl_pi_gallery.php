<div class="col-sm-<?php echo $content_width; ?> pi-gallery">
  <?php
  echo $pi_image;
  echo $pi_thumb;
  ?>
</div>

<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2020 osCommerce

  Released under the GNU General Public License
*/
?>
