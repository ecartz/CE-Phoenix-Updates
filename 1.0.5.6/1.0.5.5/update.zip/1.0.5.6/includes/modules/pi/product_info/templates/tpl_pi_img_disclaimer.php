<div class="col-sm-<?php echo $content_width; ?> pi-img-disclaimer">
  <div class="alert alert-light mt-2">
    <?php echo PI_IMG_DISCLAIMER_TEXT; ?>
  </div>
</div>

<?php
/*
  Copyright (c) 2019, G Burton

  This work is licensed under a
  Creative Commons Attribution-NonCommercial-NoDerivatives 4.0 International License.

  You should have received a copy of the license along with this work.
  If not, see <http://creativecommons.org/licenses/by-nc-nd/4.0/>.
*/
?>
