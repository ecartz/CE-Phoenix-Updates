<div class="col-sm-<?php echo $content_width; ?> pi-options-attributes mt-2">
  <h6><?php echo PI_OA_HEADING_TITLE; ?></h6>
  
  <?php echo $options_output; ?> 
</div>

<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2020 osCommerce

  Released under the GNU General Public License
*/
?>
