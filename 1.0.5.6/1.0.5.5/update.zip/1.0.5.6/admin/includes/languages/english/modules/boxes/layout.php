<?php
/*
  Copyright (c) 2019, G Burton

  This work is licensed under a
  Creative Commons Attribution-NonCommercial-NoDerivatives 4.0 International License.

  You should have received a copy of the license along with this work.
  If not, see <http://creativecommons.org/licenses/by-nc-nd/4.0/>.
*/

  define('BOX_HEADING_LAYOUT', '<i class="fas fa-puzzle-piece fa-fw mr-1"></i>Layout Modules');
  