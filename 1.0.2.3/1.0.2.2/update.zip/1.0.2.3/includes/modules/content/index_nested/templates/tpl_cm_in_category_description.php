<div class="col-sm-<?php echo $content_width; ?> cm-in-category-description">
  <div class="card mb-2 card-body">
    <?php echo $category_description; ?>
  </div>
</div>
