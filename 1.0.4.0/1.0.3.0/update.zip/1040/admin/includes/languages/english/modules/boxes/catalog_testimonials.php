<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2019 osCommerce

  Released under the GNU General Public License
*/

  define('MODULES_ADMIN_MENU_CATALOG_TESTIMONIALS', 'Testimonials');
