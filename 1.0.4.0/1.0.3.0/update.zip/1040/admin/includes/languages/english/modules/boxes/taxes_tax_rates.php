<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2019 osCommerce

  Released under the GNU General Public License
*/

  define('MOULES_ADMIN_MENU_TAXES_TAX_RATES', 'Tax Rates');
