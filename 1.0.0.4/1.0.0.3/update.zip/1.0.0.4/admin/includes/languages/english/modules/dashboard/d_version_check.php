<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2010 osCommerce

  Released under the GNU General Public License
*/

define('MODULE_ADMIN_DASHBOARD_VERSION_CHECK_TITLE', 'Version Check');
define('MODULE_ADMIN_DASHBOARD_VERSION_CHECK_DESCRIPTION', 'Show the version check results');
define('MODULE_ADMIN_DASHBOARD_VERSION_CHECK_DATE', 'Last Checked On');
define('MODULE_ADMIN_DASHBOARD_VERSION_CHECK_CHECK_NOW', 'Check Now');
define('MODULE_ADMIN_DASHBOARD_VERSION_CHECK_NEVER', 'Never');
define('MODULE_ADMIN_DASHBOARD_VERSION_CHECK_UPDATE_AVAILABLE', 'An update for OSCOM CE Phoenix is available!');
