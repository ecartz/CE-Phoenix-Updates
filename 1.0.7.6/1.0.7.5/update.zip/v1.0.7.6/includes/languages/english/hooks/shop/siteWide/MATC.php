<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2020 osCommerce

  Released under the GNU General Public License
*/

// for the page(s)
const ENTRY_MATC = 'Legal agreements';
const ENTRY_MATC_TEXT = 'By clicking this box you agree to our <a href="#" role="button" class="card-link ml-0 border-bottom border-primary" data-toggle="modal" data-target="#TCModal">T&C</a> and <a href="#" role="button" class="card-link ml-0 border-bottom border-primary" data-toggle="modal" data-target="#PModal">Privacy</a> policies.'; 

// for the modal popup
const MATC_BUTTON_CLOSE = 'Close';
