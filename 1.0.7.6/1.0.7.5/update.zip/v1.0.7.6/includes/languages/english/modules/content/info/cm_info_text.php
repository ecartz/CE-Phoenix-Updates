<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2020 osCommerce

  Released under the GNU General Public License
*/

  const MODULE_CONTENT_INFO_TEXT_TITLE = 'Text';
  const MODULE_CONTENT_INFO_TEXT_DESCRIPTION = 'Shows the Text of the Page';
